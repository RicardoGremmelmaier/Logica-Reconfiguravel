/******************************************************************************
* Module - iniche_init.c (ADAPTADO PARA XTEA 64-bit)                          *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "io.h"
#include <fcntl.h>
/* MicroC/OS-II definitions */
#include "../XTEA_bsp/HAL/inc/includes.h"
#include "../XTEA_bsp/system.h"
#include "dm9000a.h"
#include "simple_socket_server.h"
#include "alt_error_handler.h"

/* Nichestack definitions */
#include "../XTEA_bsp/iniche/src/h/nios2/ipport.h"
#include "../XTEA_bsp/iniche/src/h/tcpport.h"
#include "../XTEA_bsp/iniche/src/h/libport.h"
#include "../XTEA_bsp/iniche/src/nios2/osport.h"
#include "basic_io.h"
#include "LCD.h"

#define BUFFER_SIZE 1048576

// --- DEFINICOES DO XTEA (Do seu Qsys) ---
// Verifique se estes endereços batem com o seu Qsys!
#define XTEA_ENC_BASE 0x01a82020
#define XTEA_DEC_BASE 0x01a82000

// Offsets de Registradores (Em Bytes para IOWR/IORD)
// Reg 0 (0x00): Key[0]
// Reg 1 (0x04): Key[1]
// Reg 2 (0x08): Key[2]
// Reg 3 (0x0C): Key[3]
// Reg 4 (0x10): Data In Low
// Reg 5 (0x14): Data In High (TRIGGER START)
// Reg 6 (0x18): Data Out Low
// Reg 7 (0x1C): Data Out High / Status

OS_STK    SSSInitialTaskStk[TASK_STACKSIZE];

TK_OBJECT(to_ssstask);
TK_ENTRY(SSSSimpleSocketServerTask);

struct inet_taskinfo ssstask = {
      &to_ssstask,
      "simple socket server",
      SSSSimpleSocketServerTask,
      4,
      APP_STACK_SIZE,
};

// --- FUNCOES AUXILIARES XTEA ---

// Criptografa 64 bits (2 words)
void xtea_enc_hardware(unsigned int *key, unsigned int *in, unsigned int *out) {
    // Escreve Chave
    IOWR(XTEA_ENC_BASE, 0,  key[0]);
    IOWR(XTEA_ENC_BASE, 1,  key[1]);
    IOWR(XTEA_ENC_BASE, 2,  key[2]);
    IOWR(XTEA_ENC_BASE, 3,  key[3]); // (IOWR usa offset em words na macro ou bytes? Padrao io.h altera -> offset direto em bytes se usar IOWR_32DIRECT, mas IOWR normal multiplica por 4.
    // SE O SEU SYSTEM.H USA MACROS PADRAO, IOWR(BASE, REGNUM, VAL) escreve em BASE + REGNUM*4.
    // Entao usamos indices 0, 1, 2...
    
    // Escreve Dados
    IOWR(XTEA_ENC_BASE, 4, in[0]);
    IOWR(XTEA_ENC_BASE, 5, in[1]); // Dispara Start

    // Espera (32 clocks é muito rápido, mas por segurança)
    volatile int w; for(w=0;w<50;w++); 
    
    // Le Dados
    out[0] = IORD(XTEA_ENC_BASE, 6);
    out[1] = IORD(XTEA_ENC_BASE, 7);
}

// Descriptografa 64 bits
void xtea_dec_hardware(unsigned int *key, unsigned int *in, unsigned int *out) {
    IOWR(XTEA_DEC_BASE, 0,  key[0]);
    IOWR(XTEA_DEC_BASE, 1,  key[1]);
    IOWR(XTEA_DEC_BASE, 2,  key[2]);
    IOWR(XTEA_DEC_BASE, 3,  key[3]);

    IOWR(XTEA_DEC_BASE, 4, in[0]);
    IOWR(XTEA_DEC_BASE, 5, in[1]); // Dispara Start

    volatile int w; for(w=0;w<50;w++); 

    out[0] = IORD(XTEA_DEC_BASE, 6);
    out[1] = IORD(XTEA_DEC_BASE, 7);
}


void SSSInitialTask(void *task_data)
{
    printf("\n\nOK: projeto XTEA carregado!\n\n\n");
    INT8U error_code;

    alt_iniche_init();
    netmain();

    while (!iniche_net_ready)
        TK_SLEEP(1);

    printf("\nSimple Socket Server starting up (XTEA Version)\n");

    int SocketFD;
    struct sockaddr_in sa;
    // Buffers e Variaveis
    static char file[BUFFER_SIZE]; // Static para nao estourar a stack
    char buffer[2000];
    static char send_buffer[BUFFER_SIZE];
    
    unsigned int plaintext[4];  // 128 bits
    unsigned int enc_key[4];    // 128 bits
    unsigned int cyphertext[4]; // 128 bits
    
    // Auxiliares para XTEA (blocos de 64 bits)
    unsigned int block_in[2];
    unsigned int block_out[2];

    unsigned int file_size;
    unsigned int received_bytes = 0;

    SocketFD = socket(AF_INET, SOCK_STREAM, 6);
    printf("Socket criado.\n");
    sa.sin_family = AF_INET;
    sa.sin_port = htons(1234);
    
    // ATENCAO: Configure o IP do seu PC aqui
    sa.sin_addr.s_addr = inet_addr("10.181.28.30"); 

    if (connect(SocketFD, (struct sockaddr *)&sa, sizeof sa) == -1) {
        perror("Connection failed.\n");
        printf("Erro: %s\nVerifique se o servidor Python esta rodando no IP correto.\n", strerror(errno));
        close(SocketFD);
        exit(EXIT_FAILURE);
    }

    msleep(1000);
    char msg[16]= "Placa XTEA ON";
    send(SocketFD, msg, sizeof(msg), 0);
    printf("Conectado ao servidor!\n");

    while (1){
          int i;
          memset(buffer, 0, 17); // Limpa buffer

          if(recv(SocketFD, buffer, 17, 0) <= 0){
              printf("Erro ou desconexao no receive.\n");
              // Idealmente tentaria reconectar, mas vamos sair
              break; 
          }

          // --- COMANDO 'f': Receber Arquivo ---
          if (buffer[0] == 'f'){
              file_size = ((unsigned char)buffer[4] << 24) |
                          ((unsigned char)buffer[3] << 16) |
                          ((unsigned char)buffer[2] << 8)  |
                          ((unsigned char)buffer[1]);

              send(SocketFD, "x gravado!", 11, 0);
              msleep(100);

              received_bytes = 0;
              while(received_bytes < file_size){
                   unsigned int bytes_received = recv(SocketFD, file + received_bytes,
                                                      file_size - received_bytes, 0);
                   if(bytes_received <= 0) break;
                   received_bytes += bytes_received;
              }
              received_bytes = 0;
              send(SocketFD, "Arquivo gravado!", 16, 0);
          }

          // --- COMANDO 'a': Encriptar Texto (128 bits recebidos) ---
          else if (buffer[0] == 'a'){
              // Monta os 4 inteiros (128 bits) a partir do buffer de bytes
              for(i = 0 ; i < 4 ; i ++){
                  plaintext[i] = ((unsigned char)buffer[1+i*4] << 24) |
                                 ((unsigned char)buffer[2+i*4] << 16) |
                                 ((unsigned char)buffer[3+i*4] << 8)  |
                                 ((unsigned char)buffer[4+i*4]);
              }

              // XTEA BLOCO 1 (Words 0 e 1)
              // Nota: A ordem original era invertida [4-1-i], mantendo compatibilidade visual
              block_in[0] = plaintext[3]; // Word mais baixa? Depende da Endianess do envio
              block_in[1] = plaintext[2];
              xtea_enc_hardware(enc_key, block_in, block_out);
              cyphertext[3] = block_out[0];
              cyphertext[2] = block_out[1];

              // XTEA BLOCO 2 (Words 2 e 3)
              block_in[0] = plaintext[1];
              block_in[1] = plaintext[0];
              xtea_enc_hardware(enc_key, block_in, block_out);
              cyphertext[1] = block_out[0];
              cyphertext[0] = block_out[1];

              // Envia de volta
              send(SocketFD, (char*)cyphertext, sizeof(cyphertext), 0);
              msleep(100);
          }

          // --- COMANDO 'e': Encriptar Arquivo ---
          else if (buffer[0] == 'e'){
              int j;
              for(j = 0 ; j < file_size ; j = j + 16){
                  // Extrai 128 bits (16 bytes) do arquivo
                  for(i = 0 ; i < 4 ; i ++){
                      plaintext[i] = ((unsigned char)file[0+i*4 + j] << 24) |
                                     ((unsigned char)file[1+i*4 + j] << 16) |
                                     ((unsigned char)file[2+i*4 + j] << 8)  |
                                     ((unsigned char)file[3+i*4 + j]);
                  }

                  // Processa BLOCO 1 (Inferior)
                  block_in[0] = plaintext[3];
                  block_in[1] = plaintext[2];
                  xtea_enc_hardware(enc_key, block_in, block_out);
                  cyphertext[3] = block_out[0];
                  cyphertext[2] = block_out[1];

                  // Processa BLOCO 2 (Superior)
                  block_in[0] = plaintext[1];
                  block_in[1] = plaintext[0];
                  xtea_enc_hardware(enc_key, block_in, block_out);
                  cyphertext[1] = block_out[0];
                  cyphertext[0] = block_out[1];

                  // Serializa de volta para o buffer de envio
                  for(i = 0 ; i < 4 ; i++){
                      unsigned int intValue = cyphertext[i];
                      int k;
                      for (k = 0 ; k < 4 ; k++){
                          send_buffer[j + 4*i + k] = (unsigned char)(intValue >> (8 * (3-k)));
                      }
                  }
              }
              send(SocketFD, send_buffer, file_size, 0);
          }

          // --- COMANDO 'd': Descriptografar Arquivo ---
          else if (buffer[0] == 'd'){
              int j;
              for(j = 0 ; j < file_size ; j = j + 16){
                  for(i = 0 ; i < 4 ; i ++){
                      cyphertext[i] = ((unsigned char)file[0+i*4 + j] << 24) |
                                      ((unsigned char)file[1+i*4 + j] << 16) |
                                      ((unsigned char)file[2+i*4 + j] << 8)  |
                                      ((unsigned char)file[3+i*4 + j]);
                  }

                  // Decrypt BLOCO 1
                  block_in[0] = cyphertext[3];
                  block_in[1] = cyphertext[2];
                  xtea_dec_hardware(enc_key, block_in, block_out);
                  plaintext[3] = block_out[0];
                  plaintext[2] = block_out[1];

                  // Decrypt BLOCO 2
                  block_in[0] = cyphertext[1];
                  block_in[1] = cyphertext[0];
                  xtea_dec_hardware(enc_key, block_in, block_out);
                  plaintext[1] = block_out[0];
                  plaintext[0] = block_out[1];

                  for(i = 0 ; i < 4 ; i++){
                      unsigned int intValue = plaintext[i];
                      int k;
                      for (k = 0 ; k < 4 ; k++){
                          send_buffer[j + 4*i + k] = (unsigned char)(intValue >> (8 * (3-k)));
                      }
                  }
              }
              send(SocketFD, send_buffer, file_size, 0);
          }

          // --- COMANDO 'b': Descriptografar Texto (Bloco Único) ---
          else if(buffer[0] == 'b'){
              for(i = 0 ; i < 4 ; i ++){
                  cyphertext[i] = ((unsigned char)buffer[1+i*4] << 24) |
                                  ((unsigned char)buffer[2+i*4] << 16) |
                                  ((unsigned char)buffer[3+i*4] << 8)  |
                                  ((unsigned char)buffer[4+i*4]);
              }

              // Decrypt BLOCO 1
              block_in[0] = cyphertext[3];
              block_in[1] = cyphertext[2];
              xtea_dec_hardware(enc_key, block_in, block_out);
              plaintext[3] = block_out[0];
              plaintext[2] = block_out[1];

              // Decrypt BLOCO 2
              block_in[0] = cyphertext[1];
              block_in[1] = cyphertext[0];
              xtea_dec_hardware(enc_key, block_in, block_out);
              plaintext[1] = block_out[0];
              plaintext[0] = block_out[1];

              send(SocketFD, (char*)plaintext, sizeof(plaintext), 0);
          }

          // --- COMANDO 'k': Receber Chave ---
          else if(buffer[0] == 'k' || buffer[0] == 'q'){
              // 'q' no codigo antigo parecia fazer algo com expansao, mas no XTEA
              // a chave de decriptacao eh a mesma (o algo que muda).
              // Entao tratamos 'k' e 'q' igual: apenas salvam a chave.
              for(i = 0 ; i < 4 ; i ++){
                  enc_key[i] = ((unsigned char)buffer[1+i*4] << 24) |
                               ((unsigned char)buffer[2+i*4] << 16) |
                               ((unsigned char)buffer[3+i*4] << 8)  |
                               ((unsigned char)buffer[4+i*4]);
              }
              send(SocketFD, "Chave armazenada!", 17, 0);
              msleep(10);
          }
          
          else{
              send(SocketFD, "Comando invalido", 16, 0);
          }
    }
}

int main (int argc, char* argv[], char* envp[])
{
  INT8U error_code;
  DM9000A_INSTANCE( DM9000A_0, dm9000a_0 );
  DM9000A_INIT( DM9000A_0, dm9000a_0 );
  OSTimeSet(0);

  error_code = OSTaskCreateExt(SSSInitialTask,
                             NULL,
                             (void *)&SSSInitialTaskStk[TASK_STACKSIZE],
                             SSS_INITIAL_TASK_PRIORITY,
                             SSS_INITIAL_TASK_PRIORITY,
                             SSSInitialTaskStk,
                             TASK_STACKSIZE,
                             NULL,
                             0);
  alt_uCOSIIErrorHandler(error_code, 0);
  OSStart();
  while(1);
  return -1;
}